Santropica SMP — единый текстурпак для Minecraft 1.21.8 (Fabric / vanilla)

Состав:
- Clear Weather v1.0.0
- Actually 3D Plants
- Cigarette 3D ResourcePack
- Default Dark Mode 1.21.11-2026.4.0
- Fishing Rod 3D Reimagined 1.1.6 (by Mweed)
- Fresh Food (base + 1.21.6 shaders)
- Santropica Fish — мини-игра рыбалки
- Hardcore Hearts — кастомные сердца

Особенности:
- Мини-игра рыбалки использует тёмную текстуру сундука 9x6 из Default Dark Mode.
- Ванильная удочка: 3D-модель в руке, плоская иконка в GUI.
- Все сердца заменены на кастомный хардкор-стиль, включая состояния яда, иссушения, заморозки, поглощения и транспорта.
- Совместимость с Punchy (Fresh Food).

Установка:
1. Поместите ZIP в .minecraft/resourcepacks (или в папку resourcepacks профиля Fabric).
2. Включите пак в Настройки → Наборы ресурсов.
3. Пак должен быть выше остальных наборов.
